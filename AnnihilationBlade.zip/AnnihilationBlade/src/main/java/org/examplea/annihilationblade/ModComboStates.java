package org.examplea.annihilationblade;

import mods.flammpfeil.slashblade.init.DefaultResources;
import mods.flammpfeil.slashblade.registry.combo.ComboState;
import mods.flammpfeil.slashblade.util.AttackManager;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

import java.util.List;

public class ModComboStates {
    public static final DeferredRegister<ComboState> REGISTRY = DeferredRegister.create(ComboState.REGISTRY_KEY, Annihilationblade.MODID);

    public static final RegistryObject<ComboState> SPATIAL_FRACTURE_STATE = REGISTRY.register("spatial_fracture_state", () ->
            ComboState.Builder.newInstance()
                    .priority(100)
                    .startAndEnd(400, 460) // 动作帧
                    .motionLoc(DefaultResources.ExMotionLocation)
                    .next(entity -> new ResourceLocation("slashblade", "none"))
                    .nextOfTimeout(entity -> new ResourceLocation("slashblade", "none"))
                    .addTickAction(ComboState.TimeLineTickAction.getBuilder()
                            // === 第 5 帧：起手音效 ===
                            .put(5, (entity) -> {
                                entity.level().playSound(null, entity.getX(), entity.getY(), entity.getZ(),
                                        SoundEvents.END_PORTAL_SPAWN, SoundSource.PLAYERS, 1.0F, 0.5F);
                            })
                            // === 第 15 帧：空间破碎·万剑归宗 ===
                            .put(15, (player) -> {
                                if (player.level().isClientSide) return;
                                ServerLevel level = (ServerLevel) player.level();
                                double range = 30.0; // 攻击距离

                                // 获取面前扇形区域的敌人
                                List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class,
                                        player.getBoundingBox().inflate(range));

                                Vec3 look = player.getLookAngle().normalize();
                                Vec3 playerEye = player.getEyePosition();
                                int hitCount = 0;

                                for (LivingEntity target : targets) {
                                    if (target == player) continue;
                                    if (!target.isAlive()) continue;

                                    // 视线判定 (面前)
                                    Vec3 toTarget = target.position().add(0, target.getBbHeight()/2, 0).subtract(playerEye).normalize();
                                    if (look.dot(toTarget) > 0.5) {
                                        hitCount++;

                                        // === 核心修改：模仿参考代码使用 doSlash ===
                                        // 在目标位置产生多次剑气，模拟空间被切碎
                                        int slashCount = 8;
                                        for(int k=0; k<slashCount; k++) {
                                            // 参数：实体, 旋转角度(Roll), 偏移量, 是否静音, 是否暴击, 伤害倍率
                                            AttackManager.doSlash(
                                                    player,
                                                    player.getRandom().nextInt(360), // 随机角度，制造乱斩效果
                                                    Vec3.ZERO, // 自动锁定目标，无需偏移
                                                    true,      // 静音 (统一播放大声效)
                                                    true,      // 暴击特效
                                                    100.0f     // 基础伤害
                                            );
                                        }

                                        // 粒子特效：黑洞 + 闪电
                                        level.sendParticles(ParticleTypes.SQUID_INK, target.getX(), target.getY()+1, target.getZ(), 10, 0.5, 0.5, 0.5, 0.1);
                                        level.sendParticles(ParticleTypes.FIREWORK, target.getX(), target.getY()+1, target.getZ(), 5, 0.5, 0.5, 0.5, 0.1);

                                        // 强制秒杀 (逻辑层)
                                        TerminusLogic.execute(target, (net.minecraft.world.entity.player.Player) player);
                                    }
                                }

                                if (hitCount > 0) {
                                    // 播放破碎音效
                                    level.playSound(null, player.getX(), player.getY(), player.getZ(),
                                            SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 2.0F, 0.6F);
                                    level.playSound(null, player.getX(), player.getY(), player.getZ(),
                                            SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 2.0F, 0.1F);
                                }
                            })
                            .build()
                    )
                    .build()
    );

    public static void register(IEventBus bus) {
        REGISTRY.register(bus);
    }
}