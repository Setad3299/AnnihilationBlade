package org.examplea.annihilationblade;

import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tiers;

public class ItemAnnihilationBlade extends ItemSlashBlade {
    public ItemAnnihilationBlade() {
        super(Tiers.NETHERITE, 100, -2.4F, new Item.Properties().fireResistant().stacksTo(1));
    }

    @Override
    public boolean isDamageable(ItemStack stack) {
        return false;
    }

    // appendHoverText 删除了，移到了 ModEventHandler
}